package com.gamepanel

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class PanelService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var edge: View? = null
    private var panel: View? = null

    private lateinit var brightV: View
    private lateinit var brightP: WindowManager.LayoutParams
    private lateinit var rotV: View
    private lateinit var rotP: WindowManager.LayoutParams
    private var rotOn = false
    private lateinit var liftV: View
    private lateinit var blurV: View
    private lateinit var blurP: WindowManager.LayoutParams

    private var lastSwipe = 0L

    // состояние функций
    private var blurOn = false
    private var blurRadius = 40
    private var zoomP = 0            // 0..30  ->  1.0x .. 4.0x
    private var brightOn = false
    private var nightOn = false
    private var nightP = 40          // 0..100 -> сила осветления теней

    private val MATCH = WindowManager.LayoutParams.MATCH_PARENT
    private fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    private val passive = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createEffectWindows()
        createEdgeStrip()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        listOf(edge, panel, brightV, rotV, liftV, blurV).forEach { v ->
            try { v?.let { wm.removeView(it) } } catch (_: Exception) {}
        }
        try { magnificationController.reset(false) } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------- окна-эффекты (всегда созданы, но прозрачны, пока функция выключена) ----------

    private fun createEffectWindows() {
        // яркость на максимум: окно 1x1 с screenBrightness
        brightV = View(this)
        brightP = params(1, 1, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        brightP.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        wm.addView(brightV, brightP)

        // автоповорот: окно 1x1 принудительно разрешает поворот по датчику
        rotV = View(this)
        rotP = params(1, 1, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        rotP.screenOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        wm.addView(rotV, rotP)

        // ночное зрение: светлая вуаль, поднимает тёмные участки
        liftV = View(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        wm.addView(liftV, params(MATCH, MATCH, passive))

        // блюр
        blurV = View(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        blurP = params(MATCH, MATCH, passive)
        if (Build.VERSION.SDK_INT >= 31) {
            blurP.flags = blurP.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            blurP.blurBehindRadius = 0
        }
        wm.addView(blurV, blurP)
    }

    private fun applyBlur() {
        if (Build.VERSION.SDK_INT >= 31) blurP.blurBehindRadius = if (blurOn) blurRadius else 0
        val bg = if (!blurOn) Color.TRANSPARENT else Color.argb(if (Build.VERSION.SDK_INT >= 31) 25 else 90, 0, 0, 0)
        blurV.setBackgroundColor(bg)
        wm.updateViewLayout(blurV, blurP)
    }

    private fun applyBright() {
        brightP.screenBrightness = if (brightOn) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        wm.updateViewLayout(brightV, brightP)
    }

    private fun applyRotation() {
        rotP.screenOrientation = if (rotOn) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        wm.updateViewLayout(rotV, rotP)
    }

    private fun applyNight() {
        val alpha = if (nightOn) (nightP * 2.2f).toInt().coerceIn(0, 220) else 0
        liftV.setBackgroundColor(Color.argb(alpha, 255, 255, 255))
    }

    private fun applyZoom() {
        try {
            val mc = magnificationController
            val scale = 1f + zoomP / 10f
            if (zoomP == 0) {
                mc.reset(true)
            } else {
                mc.setScale(scale, true)
                val m = resources.displayMetrics
                mc.setCenter(m.widthPixels / 2f, m.heightPixels / 2f, true)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Зум недоступен на этом устройстве", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- полоса у левого края: ловит двойной свайп ----------

    private fun createEdgeStrip() {
        val v = View(this)
        var downX = 0f
        v.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> downX = ev.rawX
                MotionEvent.ACTION_UP -> if (ev.rawX - downX > dpi(40)) onSwipe()
            }
            true
        }
        val h = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        val p = params(dpi(20), h, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        p.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        wm.addView(v, p)
        edge = v
    }

    private fun onSwipe() {
        val now = SystemClock.uptimeMillis()
        if (now - lastSwipe < 800) {
            lastSwipe = 0
            showPanel()
        } else {
            lastSwipe = now
        }
    }

    // ---------- панель ----------

    private fun showPanel() {
        if (panel != null) return

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.argb(110, 0, 0, 0))
        root.setOnClickListener { hidePanel() }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.rgb(24, 26, 32))
                cornerRadius = dpi(20).toFloat()
            }
            setPadding(dpi(16), dpi(16), dpi(16), dpi(16))
            isClickable = true
        }

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun tab(title: String, fill: (LinearLayout) -> Unit) = Button(this).apply {
            text = title
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { content.removeAllViews(); fill(content) }
        }

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tab("🎮 Игры", ::fillGames))
            addView(tab("🎬 Видео", ::fillVideo))
        }

        card.addView(tabs)
        card.addView(content)
        card.addView(Button(this).apply {
            text = "Закрыть"
            setOnClickListener { hidePanel() }
        })
        fillGames(content)

        val scroll = ScrollView(this).apply { addView(card) }
        root.addView(scroll, FrameLayout.LayoutParams(dpi(310), FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            leftMargin = dpi(12)
        })

        wm.addView(root, params(MATCH, MATCH, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS))
        panel = root
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun fillGames(c: LinearLayout) {
        c.addView(label("Зум экрана"))
        c.addView(seek(30, zoomP) { zoomP = it; applyZoom() })
        c.addView(switch("Автоповорот экрана", rotOn) { rotOn = it; applyRotation() })
        c.addView(switch("Яркость на максимум", brightOn) { brightOn = it; applyBright() })
        c.addView(switch("Ночное зрение (видеть в темноте)", nightOn) { nightOn = it; applyNight() })
        c.addView(label("Сила ночного зрения"))
        c.addView(seek(100, nightP) { nightP = it; applyNight() })
    }

    private fun fillVideo(c: LinearLayout) {
        c.addView(switch("Блюр", blurOn) { blurOn = it; applyBlur() })
        c.addView(label("Сила блюра"))
        c.addView(seek(100, blurRadius) { blurRadius = it; applyBlur() })
        c.addView(label("Увеличение экрана"))
        c.addView(seek(30, zoomP) { zoomP = it; applyZoom() })
        c.addView(Button(this).apply {
            text = "📸 Скриншот"
            setOnClickListener { screenshot() }
        })
    }

    // ---------- скриншот ----------

    private fun screenshot() {
        hidePanel()
        main.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hb = result.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp != null) save(bmp) else toast("Не удалось сделать скриншот")
                }

                override fun onFailure(errorCode: Int) = toast("Скриншот не удался (код $errorCode)")
            })
        }, 350)
    }

    private fun save(bmp: Bitmap) {
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "GamePanel_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GamePanel")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) { toast("Не удалось сохранить"); return }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        toast("Скриншот сохранён: Pictures/GamePanel")
    }

    private fun toast(t: String) = main.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }

    // ---------- мелкие помощники для UI ----------

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 15f
        setPadding(0, dpi(10), 0, dpi(4))
    }

    private fun switch(t: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        text = t
        isChecked = on
        setTextColor(Color.WHITE)
        setPadding(0, dpi(10), 0, dpi(4))
        setOnCheckedChangeListener { _, checked -> f(checked) }
    }

    private fun seek(maxValue: Int, value: Int, f: (Int) -> Unit) = SeekBar(this).apply {
        max = maxValue
        progress = value
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) f(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }
}
