package com.gamepanel

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val text = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            text = "GamePanel\n\n" +
                "1. Нажмите кнопку ниже.\n" +
                "2. В списке найдите GamePanel и включите.\n" +
                "3. Готово: два раза проведите пальцем от левого края экрана вправо — откроется панель.\n\n" +
                "Если переключатель серый (Android 13+): Настройки → Приложения → GamePanel → три точки сверху → «Разрешить ограниченные настройки», затем повторите шаг 2."
        }
        val button = Button(this).apply {
            this.text = "Включить в спец. возможностях"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(24, 26, 32))
            setPadding(pad, pad, pad, pad)
            addView(text)
            addView(button)
        })
    }
}
